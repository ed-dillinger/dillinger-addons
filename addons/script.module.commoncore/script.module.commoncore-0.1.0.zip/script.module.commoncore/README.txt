script.modules.commoncore
========================
Welcome to the CommonCore Kodi addon.
For support go to http://tvaddons.co/.
